const express = require("express");
const docUploadRouter = express.Router();
const docUploadService = require("../services/front/docUploadService")



module.exports = docUploadRouter