import React from "react";

// import libScript from '../Allassets/assets/bundles/libscripts.bundle.js'
// import vendor from '../Allassets/assets/bundles/vendorscripts.bundle.js'
// import custom from '../Allassets/assets/js/custom.js'
// import fullCalendarScripts from '../Allassets/assets/bundles/fullcalendarscripts.bundle.js'
// import datatableScripts from '../Allassets/assets/bundles/datatablescripts.bundle.js'
// import dataTables from '../Allassets/assets/plugins/jquery-datatable/buttons/dataTables.buttons.min.js'
// import bootstrap4 from '../Allassets/assets/plugins/jquery-datatable/buttons/buttons.bootstrap4.min.js'
// import colVis from '../Allassets/assets/plugins/jquery-datatable/buttons/buttons.colVis.min.js'
// import html5 from '../Allassets/assets/plugins/jquery-datatable/buttons/buttons.html5.min.js'
// import print from '../Allassets/assets/plugins/jquery-datatable/buttons/buttons.print.min.js'
// import mainScripts from '../Allassets/assets/bundles/mainscripts.bundle.js'
// import calendar from '../Allassets/assets/js/pages/calendar/calendar.js'
// import jqueryDatatable from '../Allassets/assets/js/pages/tables/jquery-datatable.js'
function Footer() {
  return (
    <>
      
    </>
  );
}

export default Footer;
